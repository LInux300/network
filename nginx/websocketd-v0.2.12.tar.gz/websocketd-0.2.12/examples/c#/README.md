## Running the examples on Windows

1. [download and install](https://github.com/joewalnes/websocketd/wiki/Download-and-install) websocketd (don't forget to add to your PATH)
2. open and build the **Examples.sln** solution
3. double click the **run_echo.cmd** to start an echo example, go to http://localhost:8080 to interact with it
4. double click the **run_count.cmd** to start the count example, go to the [examples/html](https://github.com/joewalnes/websocketd/tree/master/examples/html) folder and double click **count.html** to open in a browser